clc
clear all;
close all;
%% 
%% OPEN CAMERA 
% VIDO_SNAP = videoinput('winvideo', 1);
% set(VIDO_SNAP, 'ReturnedColorSpace', 'RGB');
% CAM_IMG = getsnapshot(VIDO_SNAP);
% imshow(CAM_IMG)
[CAM_IMG,b]=uigetfile('*.jpg');
CAM_IMG=imread(CAM_IMG);
figure,imshow(CAM_IMG)
title('COLOR IMAGE');
CAM_IM=imresize(CAM_IMG,[512 512]);
FOOD_SEL=menu('FOOD SELECTION','IDLY','DOSA','CHAPPATHI',...
    'PAROTTA','FISH');
% if FOOD_SEL==1;
%     D=FOOD_SEL;
%     IDLY(D);
% 
% elseif FOOD_SEL==2;
%   D=FOOD_SEL;
%   DOSA(D);
% 
% elseif FOOD_SEL==3;
%   D=FOOD_SEL;
%   CHAPPATHI(D);
% 
% elseif FOOD_SEL==4;
%       D=FOOD_SEL;
%       PAROTTA(D);
% 
% else FOOD_SEL==5;
%      D=FOOD_SEL; 
%       FISH(D);
% end
%% GRAY CONVERSTION 

GRY_IMG=rgb2gray(CAM_IMG);
figure,imshow(GRY_IMG);
title('GRAY TYPE IMAGE');
% RESIZE IMAGE 
RESZ_IMG=imresize(GRY_IMG,[256 256]);
figure,imshow(RESZ_IMG);
title('RESIZED IMAGE');
%% FILTERING PROCESS
H=[0.2 0.3];
FILT_IMG=imfilter(RESZ_IMG,H);
figure,imshow(FILT_IMG)
title('FILTERD IMAGE');
HIST_IMG=histeq(FILT_IMG);
figure,imshow(HIST_IMG);
title('HISTOGRAM IMAGE');
%% FEATURES CALCULATION
aa=imresize(CAM_IMG,[256 256]);
FEAT_POINTS = detectSURFFeatures(RESZ_IMG);
figure,imshow(aa); hold on;
plot(FEAT_POINTS.selectStrongest(10)); 
hold off;
%% 

%% FOOT CROPPING PROCESS
IM_CROP=imcrop(RESZ_IMG);
figure,imshow(IM_CROP); hold on;

regions = detectMSERFeatures(IM_CROP)
plot(regions(1:10),'showPixelList', true);
hold off

%% 
% %% GRAY CONVERSION\
GRAY_IMG=IM_CROP;
figure,imshow(GRAY_IMG)

GRAY_IMG=imresize(GRAY_IMG,[256 256]);
%%  DATA BASE WITH CAPTURED IMAGE COMPARISION WITH FEATURES 
if FOOD_SEL==1;
    D=FOOD_SEL;
  IDLY(D);

elseif FOOD_SEL==2;
  D=FOOD_SEL;
  DOSA(D);

elseif FOOD_SEL==3;
  D=FOOD_SEL;
  CHAPPATHI(D);0

elseif FOOD_SEL==4;
      D=FOOD_SEL;
      PAROTTA(D);

else FOOD_SEL==5;
     D=FOOD_SEL; 
      FISH(D);
end

% 
